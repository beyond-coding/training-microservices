package com.beyondcoding.teahouse.dessertexpert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DessertExpertApplication {

	public static void main(String[] args) {
		SpringApplication.run(DessertExpertApplication.class, args);
	}
}
