package com.beyondcoding.teahouse.teaexpert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeaExpertApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeaExpertApplication.class, args);
	}
}
